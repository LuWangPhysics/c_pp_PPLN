#!/bin/sh
#title           :install_cmake.sh
#description     :download and install CMake 3.16 to specific directory.
#author		 :Yikai Kan
#date            :2019/02/25    
#usage		 :sh installation_cmake.sh <path of installation> 
#==============================================================================
if [ -z "$1" ]
  then
    echo "please specify the install path"
    exit 1
fi

mkdir $1
cd $1
wget https://github.com/Kitware/CMake/releases/download/v3.16.3/cmake-3.16.3.tar.gz
tar xvf cmake-3.16.3.tar.gz
cd $1/cmake-3.16.3 
./configure --prefix=$1
make -j 10
make install
echo "export PATH=$1/bin:$PATH" >> ~/.bashrc
source ~/.bashrc
