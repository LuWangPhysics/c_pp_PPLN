#ifndef EXTERNAL_H
#define EXTERNAL_H

#include <mpi.h>
#include <iostream>
#include <stdlib.h>                                                                 // include random number
#include <sstream>
#include <fstream>                                                                  //read and write file
#include <math.h>                                                                   // included to use the "fabs" function
#include <Eigen/Dense>
#include <typeinfo>
#include <complex>
#include <fftw3.h>
#include <algorithm>                                                                //include swap function
#include <functional>                                                               // templete of cwise operation of vector
#include <omp.h>
#include <algorithm>
#include <Eigen/LU>
#include <string>	
#include <cmath>
#include<time.h>
#include <array>
#include <vector>
#include <thread>
#include <mutex>


#endif