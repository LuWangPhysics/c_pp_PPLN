#pragma once
#include<iostream>
namespace MESH{
using std::string;
#include "spacial_r.hpp"
#include "time_frequency.hpp"
#include "spacial_z.hpp"
}
