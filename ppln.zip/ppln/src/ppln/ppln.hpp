#ifndef PPLN_H
#define PPLN_H

#include "my_discritization/Include.hpp"
#include "my_functions/Include.hpp"
#include "my_input_field_collection/Include.hpp"
#include "my_material_function/Include.hpp"
#include "my_numerical_method/Include.hpp"
#include "my_structures/Include.hpp"
#include "ext/external.hpp"

#endif
