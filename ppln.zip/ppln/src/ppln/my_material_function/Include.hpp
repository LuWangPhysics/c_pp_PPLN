#include "my_material_function/LiNb_80k.hpp"
#include "my_material_function/Gro_v.hpp"
#include "my_material_function/LiNb_final.hpp"

