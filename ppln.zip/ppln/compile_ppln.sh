#!/bin/sh
#title           :complile_ppln.sh
#description     :This script will be used to compile simulation code for ppln.
#author          :Yikai Kan
#date            :2019/02/25
#usage           :sh compile_ppln.sh <name of simulation code>
#==============================================================================
mpic++ -I build/thirdparty/boost_math/include   -I build/ppln/include -I build/thirdparty/eigen/include/eigen3/ -I build/thirdparty/fftw/include/  -L build/thirdparty/fftw/ -lfftw3 -lfftw3_threads -lm --std=c++11  -fopenmp $1 -o ${1%.cpp}
